package Lab2;

import Lab2.level.LevelGUI;

public class Main {
	public static void main(String[] args) {
		Driver driver = new Driver();
		driver.run();
		
	}
}
